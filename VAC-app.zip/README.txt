Violence Armies for Christ (VAC) - how to publish

1. Unzip this folder.
2. Go to netlify.com/drop (or Vercel, or GitHub Pages) and drag the whole folder in. You get a web link.
3. Open the link on your phone and choose Add to Home Screen. It installs like an app.

Note: on your own site, posts, follows and chat stay on each person's device. To share them between everyone you need a backend (for example Supabase). For Google Play or the App Store, wrap the site with pwabuilder.com.
